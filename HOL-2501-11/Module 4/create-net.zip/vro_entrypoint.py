import sys
sys.path.append('.')
import create_nsx_network
import json

def handler(context, inputs):
    jsonOut=json.dumps(inputs, separators=(',', ':'))
    print("Inputs were {0}".format(jsonOut))

    outputs = {
      "status": "done"
    }

    create_nsx_network.main(inputs['name'], inputs['gateway'])

    return outputs
